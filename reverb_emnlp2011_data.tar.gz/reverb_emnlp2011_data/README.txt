Data for ``Identifying Relations for Open Information Extraction''
Anthony Fader (afader@cs.washington.edu)
Stephen Soderland (soderlan@cs.washington.edu)
Oren Etzioni (etzioni@cs.washington.edu)

To download the code for ReVerb, please visit http://reverb.cs.washington.edu.

The files are:

|-- analysis.txt                        The data used in Section 3.3
|-- sentences.txt                       The sentences used in Section 5
|-- extractions                         The system output from Section 5
|   |-- reverb.txt                      
|   |-- reverb_no_lex.txt               
|   |-- textrunner.txt                  
|   |-- textrunner_reverb.txt
|   |-- woe_parse.txt
|   |-- woe_pos.txt
|-- labels.txt                          The agreed labels from Section 5
|-- reverb_emnlp2011.pdf                A copy of the paper

analysis.txt

    This file contains verbal relation phrases manually identified from Wu and
    Weld's 300 Web sentences (Wu and Weld, 2010). Each line corresponds to 
    a (sentence, relation phrase) pair and a set of 5 features:
        - Is the relation phrase is contiguous in the sentence?
        - Does the relation phrase match the ReVerb POS pattern?
        - Do the arguments appear to the left and right of the relation phrase?
        - Does the relation phrase satisfy the ReVerb syntactic constraints
          (this is the logical AND of the previous three features).
        - If this relation phrase does not satisfy the constraints, a reason
          why.
    The fields on each line are tab-separated, with a header row labeling the
    columns.

sentences.txt

    This file contains a set of 500 Web sentences sampled from Yahoo's random
    link generator (http://random.yahoo.com/bin/ryl). Each line is a pair
    (sentence id, sentence), separated by a tab.

extractions

    This directory contains the output of the extractors run on sentences.txt.
    Each file has the following fields:
        - Sentence id: the id from sentences.txt
        - Argument1:   the first argument
        - Relation:    the relation phrase
        - Argument2:   the second argument
        - Confidence:  a numeric score assigned to this extraction

labels.txt
    
    This file contains a list of extractions and their labels (either incorrect
    or correct). These are the extractions where the two human annotators
    reached an agreement on the labels. The file has the following fields:
        - Label, either 0 (incorrect) or 1 (correct)
        - Sentence id
        - Argument1
        - Relation
        - Argument2
